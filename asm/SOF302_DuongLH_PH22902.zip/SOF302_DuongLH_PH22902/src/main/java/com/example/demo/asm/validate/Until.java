package com.example.demo.asm.validate;

public class Until {
    public static final String NUMBER = "[0-9.9]{1,10}";
    public static final String TEXT = "[a-z A-Z]+";
    public static final int CODE_LENGHT = 5;
    public static final int PHONE_NUMBER_LENGHT = 10;
    public static final int MIN_PASSWORD = 3;
}
